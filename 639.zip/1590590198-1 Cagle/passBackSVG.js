function passBackSVG(){
    var embedNodes=document.embeds;
    for (var i=0;i<embedNodes.length;i++){
        embedNode=embedNodes[i];
        if(embedNode.window.passState){
            embedNode.window.passState(embedNode);
            }
        }
    }       
