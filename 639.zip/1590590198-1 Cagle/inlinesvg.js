//<script languag="JavaScript">
//<author>Chris@bayes.co.uk</author>
//<website>http://www.bayes.co.uk</website>
//<disclaimer>This software may be used as long as this 
//header stays intact. No responsibility is accepted
//for use of this software.</disclaimer>
//debugger;
function inlineSVGdomtodom(svg, embed){
	//debugger;
	try{
	var svgdoc = document.embeds[embed].getSVGDocument();
		for (i=svgdoc.childNodes.length-1; i >=0 ; i--){
			svgdoc.removeChild(svgdoc.childNodes(i));
		}
		inlineSVGcopyNode(svg, svgdoc, svg, svgdoc);
	}catch(e){
		alert("Error in embedded SVG. " + e.description);
	}
}
function inlineSVGcopyNode(snode, dnode, svg, svgdoc){
	var i=0;
	var newNode = null;
	for(i=0; i < snode.childNodes.length; i++){
		switch(snode.childNodes[i].nodeType){
			case 1: //NODE_ELEMENT
				newNode = svgdoc.createElement(snode.childNodes[i].nodeName);
				inlineSVGcopyAttributes(snode.childNodes[i], newNode);
				break;
			case 2: //NODE_ATTRIBUTE
				newNode = svgdoc.createAttribute(snode.childNodes[i].nodeName);
				break;
			case 3: //NODE_TEXT
				newNode = svgdoc.createTextNode(snode.childNodes[i].nodeValue);
				break;
			case 4: //NODE_CDATA_SECTION 
				newNode = svgdoc.createCDATASection(snode.childNodes[i].nodeValue);
				break;
			case 5: //NODE_ENTITY_REFERENCE 
				newNode = svgdoc.createEntityReference(snode.childNodes[i].nodeName);
				break;
			case 6: //NODE_ENTITY 
				break;
			case 7: //NODE_PROCESSING_INSTRUCTION 
				newNode = svgdoc.createProcessingInstruction("xml", snode.childNodes[i].nodeValue);
				break;
			case 8: //NODE_COMMENT 
				newNode = svgdoc.createComment(snode.childNodes[i].nodeValue);
				break;
			case 9: //NODE_DOCUMENT
				break
			case 10: //NODE_DOCUMENT_TYPE 
				break;
			case 11: //NODE_DOCUMENT_FRAGMENT 
				newNode = svgdoc.createDocumentFragment();
				break;
			case 12: //NODE_NOTATION 
				break;
			default:
		}
		if (newNode != null){
			dnode.appendChild(newNode);
			inlineSVGcopyNode(snode.childNodes[i], newNode, svg, svgdoc);
		}
	}
}
function inlineSVGcopyAttributes(sNode, dNode){
	var i=0;
	for (i=0; i < sNode.attributes.length; i++){
		dNode.setAttribute(sNode.attributes[i].nodeName, sNode.attributes[i].nodeValue);
	}
}
var inlineSVGembededObjects = new Array();
var inlineSVGwindowTimeoutId = null;
function inlineSVGembedObject(x, i){
	this.xml = x;
	this.id = i;
	inlineSVGembededObjects[inlineSVGembededObjects.length] = this;
}
function inlineSVGinitInlineSVG(){
	var s = document.all.tags("svg");
	for (i=s.length-1; i >=0 ; i--){
		var id = s[i].id;
		var x = new ActiveXObject("Msxml2.DOMDocument");
		var nspns = /\<\?xml\:namespace prefix \= (.*?) ns \= \"(.*?)" \/\>/.exec(s[i].outerHTML);
		var svg = s[i].outerHTML.replace(/\<\?xml\:namespace prefix \= (.*?) ns \= \"(.*?)" \/\>/, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
//		var re = new RegExp("id\=" + id,"g");
        var re=new RegExp("id\=(\[A-Za-z0-9_]+)","g");
//		svg = svg.replace(re, "id=\'" + id + "\' ");
        svg= svg.replace(re,"id=\"$1\"");
		re = new RegExp("<" + nspns[1] + ":", "g");
		svg = svg.replace(re, "<");
		re = new RegExp("</" + nspns[1] + ":", "g");
		svg = svg.replace(re, "</");
		x.loadXML(svg)
		s[i].outerHTML = "<embed height=\"" + s[i].height + "\" width=\"" + s[i].width + "\" type=\"image/svg-xml\" src=\"dummy.svg\" id=\"" + id + "\">";
		var n = new inlineSVGembedObject(x, id);
		if (inlineSVGwindowTimeoutId == null){
			inlineSVGwindowTimeoutId = window.setInterval("inlineSVGloadSVG()", 100); // 100 milliseconds
		}
	}
}
function inlineSVGloadSVG(){
	window.clearInterval(inlineSVGwindowTimeoutId);
	var eocount = 0;
	for (var i=0; i < inlineSVGembededObjects.length; i++){
		if (inlineSVGembededObjects[i] != null){
			if (document.all(inlineSVGembededObjects[i].id).readyState == "complete"){
				inlineSVGdomtodom(inlineSVGembededObjects[i].xml, inlineSVGembededObjects[i].id);
				inlineSVGembededObjects[i] = null;
			}else{
				eocount++;
			}
		}
	}
	if (eocount > 0)
		inlineSVGwindowTimeoutId = window.setInterval("loadSVG()", 100); // 100 milliseconds
}
//</script>