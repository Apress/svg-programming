// JScript source code
function call(xmlDoc,xslID){
	var xmlDoc=new ActiveXObject("MSXML.DOMDocument");	
	var xslDoc=new ActiveXObject("MSXML.DOMDocument");
	var rsltDoc=new ActiveXObject("MSXML.DOMDocument");
	rsltDoc.setProperty("SelectionLanguage","XPath");
	xmlDoc.loadXML(r);
	xmlDoc
	xslDoc.load(toLower.XMLDocument);
	xmlDoc.transformNodeToObject(xslDoc,rsltDoc);
	return rsltDoc
	}