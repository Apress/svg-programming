var fso=null;
var Files=null;
var eFiles=null;
var scrollbar=null;

function passBackSVG(){
    var embedNodes=document.embeds;
    for (var i=0;i<embedNodes.length;i++){
        embedNode=embedNodes[i];
        if(embedNode.window.passState){
            embedNode.window.passState(embedNode);
            }
        }
    }       

function initFSO(){
    fso=new ActiveXObject("Scripting.FileSystemObject");
    }


function updateBackground(){
    scrollbar=document.all("scrollbar");
    filePos=parseInt(scrollbar.getValue());
    eFiles.moveFirst();
    while (filePos--){
        eFiles.moveNext();    
        
        }
    var file=eFiles.item();
    document.all("value").innerHTML=parseInt(scrollbar.getValue())+")"+file.name;
    document.body.setAttribute("background",file.path);
    }

function setFolder(folder){
    Files=fso.getFolder(folder).files;
    eFiles=new Enumerator(Files);
    scrollbar=document.all("scrollbar");
    scrollbar.setMaxValue(Files.count-1);    
    }
    
function initDisplay(folder){
    passBackSVG();
    initFSO();
    setFolder(folder);
    updateBackground()
    }        