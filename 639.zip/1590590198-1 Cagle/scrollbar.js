var svgDoc=null;
var buttonPressed=false;
var bed=null;
var bedXMin=0;
var bedXMax=0;
var thumb=null;
var thumbWidth=0;
var sliderPos=null;
var value=0;
var minValue=0;
var maxValue=1;
var scaleFactor=1;
var embedId="local";
var embed;

function initSVG(evt){
    svgDoc=evt.target.ownerDocument;
    }
    
function passState(extEmbed){
    embed=extEmbed;
    embed.setMaxValue=setMaxValue;
    embed.setMinValue=setMinValue;
    embed.setValue=setValue;
    embed.getValue=getValue;
    sliderPos=getTranslate("slider");
    bed=svgDoc.getElementById("bed");
    track=svgDoc.getElementById("track");
    thumb=svgDoc.getElementById("thumb");
    var svgNode=svgDoc.getElementsByTagName("svg").item(0);

    embedWidth=parseFloat(embed.getAttribute("width"));
    embedHeight=parseFloat(embed.getAttribute("height"));
    bedXMin = parseFloat(bed.getAttribute("x"));
    scaleFactorX=parseFloat(track.getAttribute("width"))/embedWidth;
    scaleFactorY=parseFloat(svgNode.getAttribute("height"))/embedHeight;
    bedWidth = parseFloat(track.getAttribute("width"));
    thumbWidth=thumb.getAttribute("width");
//    alert(scaleFactorY);
    thumb.setAttribute("transform","scale("+ (scaleFactorX) + ","+(1)+")");
    
    if (embed.getAttribute("value")!=""){
        value=parseFloat(embed.getAttribute("value"));
        }
    if (embed.getAttribute("minValue")!=""){
        minValue=parseFloat(embed.getAttribute("minValue"));
        }
    if (embed.getAttribute("maxValue")!=""){
        maxValue=parseFloat(embed.getAttribute("maxValue"));
        }
    if (embed.id!=""){
        embedId=embed.id;
        }
    }    
    
function beginMoveThumb(evt){
    buttonPressed=true;
    if (embed.getAttribute("onthumbpress")!=null){
        embed.window.eval(embed.getAttribute("onthumbpress"));
        }
    }

function endMoveThumb(evt){
    buttonPressed=false;
    if (embed.getAttribute("onthumbrelease")!=null){
        embed.window.eval(embed.getAttribute("onthumbrelease"));
        }
    
    }

function clickBed(evt){
    buttonPressed=true;
    moveThumb(evt);
    if (embed.getAttribute("onbedclick")!=null){
        embed.window.eval(embed.getAttribute("onbedclick"));
        }
    buttonPressed=false;
    }    
    
function moveThumb(evt){
    if(buttonPressed){
        clientX=evt.clientX;
        var posX=Math.min(Math.max(clientX*scaleFactorX,thumbWidth),(bedWidth) - thumbWidth);
        value=minValue + (maxValue-minValue)*(posX-thumbWidth)/(bedWidth - 2 * thumbWidth);
    if (embed.getAttribute("onthumbmove")!=null){
        embed.window.eval(embed.getAttribute("onthumbmove"));
        }
        thumb.setAttribute("transform","translate("+posX+",0)");
        }
    }

function getTranslate(elemId){
    var elem=svgDoc.getElementById(elemId);
    var translate=elem.getAttribute('transform');
    var re=/translate\((-?[0-9]+),(-?[0-9]+)\)/;
    if(re.test(translate)){
        x=parseFloat(RegExp.$1);
        y=parseFloat(RegExp.$2);
        var obj=new Object;
        obj.x=x;
        obj.y=y;
        return obj;
        }
    else {
        return null;
        }        
    }   

function setValue(newValue){
    value=newValue;
    posX=thumbWidth + (bedWidth - 2* thumbWidth)* ((value-minValue)/(maxValue-minValue));
    thumb.setAttribute("x",posX + sliderPos.x);
    if (embed.getAttribute("onchange")!=null){
        embed.window.eval(embed.getAttribute("onchange"));
        }
    }    
    
function setMinValue(minVal){
    minValue=minVal;
    }
    
function getValue(){
    return value;
    }        

function setMaxValue(maxVal){
    maxValue=maxVal;
    }    
