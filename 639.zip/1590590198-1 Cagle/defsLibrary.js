var svgDoc=null;
var embedObject=null;
var loadObject=null;

function initSVG(evt){
    svgDoc=evt.target.ownerDocument;
    }

function passStateExt(extObject,loadObject_){
    embedObject=extObject;
    loadObject=loadObject_;
    loadExternalDefs();
    }      
    
function loadExternalDefs(){
    var nodelist=svgDoc.getElementsByTagName("ext:load");
    for (var i=0;i<nodelist.length;i++){
        var extNode=nodelist.item(i);
        var externalURL=extNode.getAttributeNS("http://www.w3.org/1999/xlink","href");
        var xmlDoc=loadObject("MSXML2.FreeThreadedDomDocument");
        xmlDoc.async=false;
        xmlDoc.load(externalURL);
        var rootNode=xmlDoc.documentElement;
        var svgNode=mapXMLToSVG(rootNode);        
        extNode.parentNode.replaceChild(svgNode,extNode);
        }
    }
    
function mapXMLToSVG(xmlNode,svgParentNode){
    switch(xmlNode.nodeTypeString){
        // Match an element
        case "element":
               if (xmlNode.namespaceURI!=""){
                    var svgElement=svgDoc.createElementNS(xmlNode.namespaceURI,xmlNode.nodeName);
                    }
               else {                    
                   var svgElement=svgDoc.createElement(xmlNode.nodeName);
                   }
               for (var i=0;i<xmlNode.attributes.length;i++){
                    var attr=xmlNode.attributes.item(i);
                    if(attr.namespaceURI!=""){
                        svgElement.setAttributeNS(attr.namespaceURI,attr.nodeName,attr.value);
                        }
                    else {
                        svgElement.setAttribute(attr.nodeName,attr.value);                    
                        }                   
                    }
               if (""+svgParentNode != "undefined"){
                    svgParentNode.appendChild(svgElement);
                    }                    
               for (var i=0;i<xmlNode.childNodes.length;i++){
                    var childNode=xmlNode.childNodes.item(i);
                     mapXMLToSVG(childNode,svgElement);
                    }
               break;
            case "text":
               var svgText=svgDoc.createTextNode(xmlNode.text);
               svgParentNode.appendChild(svgText);
               break;
            case "comment":
               var svgComment=svgDoc.createComment(xmlNode.text);
               svgParentNode.appendChild(svgComment);
            case "cdatasection":
               var svgCDATASection=svgDoc.createCDATASection(xmlNode.nodeValue);
               svgParentNode.appendChild(svgCDATASection);
        default:break;               
        }
        return svgElement;
    }