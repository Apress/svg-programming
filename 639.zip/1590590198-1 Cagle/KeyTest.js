var curPos=0;
function getNextMetrics(evt){
	var svg=evt.target.ownerDocument;
	var text=svg.getElementById("selText");
	var mLength=text.getSubStringLength(curPos,1);
	if (mLength > 0){
		curPos++;
		var cursor=svg.getElementById("cursor");
		cursor.setAttribute("x",parseFloat(cursor.getAttribute("x"))+mLength);
		window.status=curPos
		}
	}

function getPreviousMetrics(evt){
	var svg=evt.target.ownerDocument;
	var text=svg.getElementById("selText");
	if(curPos &gt;0){
		var mLength=text.getSubStringLength(curPos - 1,1);
		curPos--;
		var cursor=svg.getElementById("cursor");
		cursor.setAttribute("x",parseFloat(cursor.getAttribute("x"))-mLength);
		window.status=curPos
		}
	}

function addCharacter(evt){
	var svg=evt.target.ownerDocument;
	var text=svg.getElementById("selText");
	var textData=text.childNodes(0).getData();
	code=evt.keycode;
	var ch=String.fromCharCode(code);
	if (!evt.shiftKey){
		if (ch > 64 && ch < 91){
			ch += 32;
			}
		}
	textData=textData.substring(0,curPos)+ch+textData.substring(curPos);
	text.childNodes(0).setData(textData);
	getNextMetrics(evt);
	}

function deleteCharacter(evt){
	getPreviousMetrics(evt);
	var svg=evt.target.ownerDocument;
	var text=svg.getElementById("selText");
	textData=text.childNodes(0).getData();
	textData=textData.substring(0,curPos)+textData.substring(curPos+1);
	text.childNodes(0).setData(textData);
	}	
	
	
function getKeycode(evt){
	code=evt.keycode;
	switch(code){
	case 37: // left arrow
		getPreviousMetrics(evt);
		break;
	case 39: //right arrow
		getNextMetrics(evt);
		break;
	case 8: //BkSpace key
		deleteCharacter(evt);
		break;
	default:
		addCharacter(evt);
		break;		
		}	
	}			
