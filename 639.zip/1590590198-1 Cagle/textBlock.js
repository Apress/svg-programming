var svgDoc=null;

function initSVG(evt){
    svgDoc=evt.target.ownerDocument;
    }
        
function processTextBlocks(){
   svgDoc.documentElement.setAttribute("image-rendering","optimizedSpeed");
   svgDoc.documentElement.setAttribute("text-rendering","optimizedSpeed");
   var nodelist=svgDoc.getElementsByTagName("ext:textBlock");
    for (var i=0;i<nodelist.length;i++){
        var extNode=nodelist.item(i);
        var fontSize=extNode.getAttribute("font-size");
        var fontFamily=extNode.getAttribute("font-family");
        leading=parseFloat(fontSize) * 1.2;
        if (extNode.getAttribute("text-anchor")!=null){
            textAnchor=extNode.getAttribute("text-anchor");
            }
        else {
            textAnchor="start";
            }            
        var width=extNode.getAttribute("width");      
        var id=extNode.getAttribute("id");
        var gElement=svgDoc.createElement("g");        
        gElement.setAttribute("font-size",fontSize);
        gElement.setAttribute("font-family",fontFamily);
        gElement.setAttribute("id",id);
        var textElement=svgDoc.createElement("text");
        textElement.setAttribute("text-anchor",textAnchor);
        gElement.appendChild(textElement);
        lineCount=0;
        pList=extNode.getElementsByTagName("p");
        for (var j=0;i<pList.length;j++){
            var pNode=pList.item(j);
            var text=pNode.firstChild.getData();
            buffer="";
            while (text.length != 0){
                var tspanElement=svgDoc.createElement("tspan");
                tspanElement.appendChild(svgDoc.createTextNode("."));
                textElement.appendChild(tspanElement);
                tspanElement.setAttribute("x",0);
                tspanElement.setAttribute("y",lineCount * leading);
                while (width > tspanElement.getComputedTextLength()){
                    var completedFlag=false;
                    spacePos=text.indexOf(" ");
                    if (spacePos != -1){
                        oldBuffer=buffer;
                        word = text.substring(0,spacePos);
                        buffer=buffer+word+" ";
                        tspanElement.firstChild.setData(buffer);
                        text=text.substring(spacePos+1);
                        }
                    else{ 
                        completedFlag=true;
                        word=text;
                        oldBuffer=buffer;
                        buffer=buffer+word+" ";
                        tspanElement.firstChild.setData(buffer);
                        if (tspanElement.getComputedTextLength()>width){
                            tspanElement.firstChild.setData(oldBuffer);
                            lineCount++;
                            var tspanElement=svgDoc.createElement("tspan");
                            tspanElement.appendChild(svgDoc.createTextNode("."));
                            textElement.appendChild(tspanElement);
                            tspanElement.setAttribute("x",0);
                            tspanElement.setAttribute("y",(lineCount) * leading);
                            tspanElement.firstChild.setData(word);
                            lineCount=lineCount+1;
                            }
                        break;                    
                        }
                    }
                if (!completedFlag){    
                    tspanElement.firstChild.setData(oldBuffer);
                    buffer=word+" ";
                    lineCount++;
                    }
                else {
                    lineCount=lineCount+2;
                    break;
                    }
                                                    
                }
            if (j==pList.length-1){
                var parentNode=extNode.parentNode;
                parentNode.replaceChild(gElement,extNode);
                }
            }
        }
        
    }    
    
